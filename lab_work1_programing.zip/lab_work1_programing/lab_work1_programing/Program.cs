﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

//Дано структуру даних(колекцію) відповідно до варіанта.Додати
//зазначену кількість елементів, які описують відповідну предметну
//область.Вивести всі елементи на консоль в прямому та зворотному
//порядку.Вивести кількість елементів у колекції.Очистити колекцію.
//Stack Назви типів даних мови C# 10
class Program
{
    //static Stack<string> GetStack()
    //{
    //    Stack<string> stack1 = new Stack<string>();
    //    stack1.Push("int");
    //    stack1.Push("long");
    //    stack1.Push("short");
    //    stack1.Push("byte");
    //    stack1.Push("float");
    //    stack1.Push("bool");
    //    stack1.Push("char");
    //    stack1.Push("string");
    //    stack1.Push("object");
    //    stack1.Push("ushort");
    //    return stack1;
    //}



    static void Main()
    {
        Console.WriteLine("--- Exercise №1 ---");
        string[] value = { "int", "long", "short", "byte", "float", "bool", "char", "string", "object", "ushort" };
        var stack1 = new Stack<string>(value);
        Console.WriteLine("--- Stack contents ---");
        foreach(string i in stack1)
        {
            Console.WriteLine(i);
        }
        Console.WriteLine("--- Stack contents reversed ---");
        foreach (string i in stack1.Reverse())
        {
            Console.WriteLine(i);
        }
        Console.WriteLine("--- Stack contents quantity ---");
        Console.WriteLine("Кількість елементів у стеку: " + stack1.Count());
        stack1.Clear();
        Console.WriteLine("Кількість елементів у стеку: " + stack1.Count());

        Console.WriteLine("--- Exercise №1 ends ---");

        Console.WriteLine("--- --- ---");
        Console.WriteLine("--- Exercise №2 ---");
        //Дано чергу цілих чисел, яка складається з n елементів.
        //Визначити середнє арифметичне значення елементів черги,
        //кратних восьми.Якщо таких елементів немає, вивести
        //повідомлення: «Елементів кратних 8 в черзі немає».
        const int n = 50;
        int count = 0;
        int sum = 0;
        int middleNum = 0;

        //Перевірити чи працює алгоритм на перевірку кратності
        //Queue<int> q = new Queue<int>();
        //q.Enqueue(5);
        //q.Enqueue(10);
        //q.Enqueue(15);
        //q.Enqueue(20);
        //q.Enqueue(56);
        //q.Enqueue(16);
        //q.Enqueue(24);


        Queue<int> q = new Queue<int>();
        Random rnd = new Random();
        for (int i = 0; i < n; i++)
        {
            q.Enqueue(rnd.Next(1, 100));
        }
        foreach (int i in q)
        {
            if(i % 8 == 0)
            {
                count++;
                sum += i;
                Console.WriteLine(i);
            }
        }
        if ((count) == 0)
        {
            Console.WriteLine("Нема кратних 8 чисел");
            
        } else {

            Console.WriteLine("Числа кратні 8:" + count);
        }

        middleNum = sum / count;
        Console.WriteLine("Середнє арефметичне: " + middleNum);
        
    }
}