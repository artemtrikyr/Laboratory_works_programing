﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_work2_programing
{
    public class Supply
    {
        public int ProductId { get; set; }
        public DateTime SupplyDate { get; set; }
        public int Quantity { get; set; }
    }
}

