﻿using System;
using System.Collections.Generic;


namespace lab_work2_programing
{
    public static class Data
    {
        public static List<Product> Products = new List<Product>
        {
            new Product { ProductId = 1, Name = "Apple", Price = 2 },
            new Product { ProductId = 2, Name = "Banana", Price = 6 },
            new Product { ProductId = 3, Name = "Orange", Price = 3 },
            new Product { ProductId = 4, Name = "Mango", Price = 4 },
            new Product { ProductId = 5, Name = "Apple", Price = 7 },
            new Product { ProductId = 6, Name = "Pineapple", Price = 5 },
            new Product { ProductId = 7, Name = "Grapes", Price = 8 },
            new Product { ProductId = 8, Name = "Lemon", Price = 3 },
            new Product { ProductId = 9, Name = "Kiwi", Price = 6 },
            new Product { ProductId = 10, Name = "Strawberry", Price = 10 },
            new Product { ProductId = 11, Name = "Blueberry", Price = 15 },
            new Product { ProductId = 12, Name = "Peach", Price = 4 },
            new Product { ProductId = 13, Name = "Cherry", Price = 9 },
            new Product { ProductId = 14, Name = "Plum", Price = 5 },
            new Product { ProductId = 15, Name = "Watermelon", Price = 12 },
            new Product { ProductId = 16, Name = "Cantaloupe", Price = 13 },
            new Product { ProductId = 17, Name = "Coconut", Price = 7 },
            new Product { ProductId = 18, Name = "Papaya", Price = 6 },
            new Product { ProductId = 19, Name = "Lychee", Price = 11 },
            new Product { ProductId = 20, Name = "Raspberry", Price = 14 },
            new Product { ProductId = 21, Name = "Blackberry", Price = 13 },
            new Product { ProductId = 22, Name = "Apricot", Price = 4 },
            new Product { ProductId = 23, Name = "Rajec", Price = 5}
        };

        public static List<Supply> Supplies = new List<Supply>
        {
            new Supply { ProductId = 1, SupplyDate = new DateTime(2023, 9, 20), Quantity = 50 },
            new Supply { ProductId = 1, SupplyDate = new DateTime(2022, 8, 15), Quantity = 60 },
            new Supply { ProductId = 2, SupplyDate = new DateTime(2023, 7, 18), Quantity = 100 },
            new Supply { ProductId = 3, SupplyDate = new DateTime(2021, 3, 10), Quantity = 30 },
            new Supply { ProductId = 4, SupplyDate = new DateTime(2021, 4, 25), Quantity = 80 },
            new Supply { ProductId = 5, SupplyDate = new DateTime(2022, 10, 12), Quantity = 40 },
            new Supply { ProductId = 6, SupplyDate = new DateTime(2023, 9, 10), Quantity = 120 },
            new Supply { ProductId = 7, SupplyDate = new DateTime(2021, 5, 17), Quantity = 35 },
            new Supply { ProductId = 8, SupplyDate = new DateTime(2022, 6, 22), Quantity = 90 },
            new Supply { ProductId = 9, SupplyDate = new DateTime(2023, 3, 30), Quantity = 110 },
            new Supply { ProductId = 10, SupplyDate = new DateTime(2022, 4, 5), Quantity = 70 },
            new Supply { ProductId = 11, SupplyDate = new DateTime(2021, 9, 12), Quantity = 40 },
            new Supply { ProductId = 12, SupplyDate = new DateTime(2023, 2, 14), Quantity = 60 },
            new Supply { ProductId = 13, SupplyDate = new DateTime(2023, 8, 30), Quantity = 75 },
            new Supply { ProductId = 14, SupplyDate = new DateTime(2022, 1, 21), Quantity = 85 },
            new Supply { ProductId = 15, SupplyDate = new DateTime(2023, 7, 7), Quantity = 55 },
            new Supply { ProductId = 16, SupplyDate = new DateTime(2022, 3, 17), Quantity = 90 },
            new Supply { ProductId = 17, SupplyDate = new DateTime(2021, 12, 20), Quantity = 100 },
            new Supply { ProductId = 18, SupplyDate = new DateTime(2022, 6, 1), Quantity = 65 },
            new Supply { ProductId = 19, SupplyDate = new DateTime(2023, 5, 9), Quantity = 130 },
            new Supply { ProductId = 20, SupplyDate = new DateTime(2021, 7, 23), Quantity = 75 },
            new Supply { ProductId = 21, SupplyDate = new DateTime(2022, 11, 29), Quantity = 85 },
            new Supply { ProductId = 22, SupplyDate = new DateTime(2023, 8, 4), Quantity = 120 },
            new Supply { ProductId = 23, SupplyDate = new DateTime(2021, 7, 23), Quantity = 47}
        };
    }
}
