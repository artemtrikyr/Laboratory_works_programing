﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace lab_work2_programing
{
    class Program
    {
        static void Main(string[] args)
        {
            // Виклик методів для демонстрації задач
            Tasks.TaskA();
            Tasks.TaskB("Apple");
            Tasks.TaskC();
        }
    }
}

