﻿using System;
namespace lab_work2_programing
{
    public class EmptyClass
    {
        public EmptyClass()
        {
        }
    }
}

