﻿using System;
using System.Linq;


namespace lab_work2_programing
{
    public static class Tasks
    {
        // Task a) Вивести без повторів назви товарів
        public static void TaskA()
        {
            var uniqueProductNames = Data.Products
                .Select(p => p.Name)
                .Distinct();

            Console.WriteLine("Унікальні назви товарів:");
            foreach (var name in uniqueProductNames)
            {
                Console.WriteLine(name);
            }
        }

        // Task b) Вивести максимальний обсяг поставок товару із заданою назвою
        public static void TaskB(string productName)
        {
            var maxSupply = (from p in Data.Products
                             join s in Data.Supplies on p.ProductId equals s.ProductId
                             where p.Name == productName
                             select s.Quantity)
                            .Max();

            Console.WriteLine($"Максимальний обсяг поставок для товару \"{productName}\": {maxSupply}");
        }

        // c) Вивести середні загальні вартості поставок товарів по кожному року
        public static void TaskC()
        {
            var avgAnnualSupplyCosts = from s in Data.Supplies
                                       join p in Data.Products on s.ProductId equals p.ProductId
                                       group new { s.Quantity, p.Price } by s.SupplyDate.Year into yearlyGroup
                                       select new
                                       {
                                           Year = yearlyGroup.Key,
                                           AverageCost = yearlyGroup.Average(x => x.Quantity * x.Price)
                                       };

            Console.WriteLine("Середні загальні вартості поставок по кожному року:");
            foreach (var item in avgAnnualSupplyCosts)
            {
                Console.WriteLine($"Рік: {item.Year}, Середня вартість: {item.AverageCost:C}");
            }
        }
    }
}
