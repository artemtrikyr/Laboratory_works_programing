﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace ConsoleAppJson
{
    public class Painting
    {
        [JsonProperty(PropertyName = "code")]
        public int Code { get; set; }

        [JsonProperty(PropertyName = "artist")]
        public string Artist { get; set; }

        [JsonProperty(PropertyName = "title")]
        public string Title { get; set; }

        [JsonProperty(PropertyName = "price")]
        public int Price { get; set; }

        [JsonProperty(PropertyName = "status")] // 1 – в експозиції, 2 – в запаснику, 3 – на "виїзді"
        public double Status { get; set; }

    }

    public class Gallery
    {
        [JsonProperty(PropertyName = "paintsList")]
        public List<Painting> Paintings { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            

            // Приклад перетворення складного обєкту
            var stringJsonData = @"
            {
                'paintsList': [
                    {
                      'code': 001,
                      'artist': 'Петренко',
                      'title': 'Сонце',
                      'price': 1000,
                      'status': 1
                    },
                    {
                      'code': 002,
                      'artist': 'Іваненко',
                      'title': 'Море',
                      'price': 2000,
                      'status': 2
                    },
                    {
                      'code': 003,
                      'artist': 'Сидоренко',
                      'title': 'Ліс',
                      'price': 3000,
                      'status': 3
                    },
                    {
                      'code': 004,
                      'artist': 'Коваленко',
                      'title': 'Гори',
                      'price': 1500,
                      'status': 2
                    },
                    {
                      'code': 005,
                      'artist': 'Лисенко',
                      'title': 'Озеро',
                      'price': 4500,
                      'status': 2
                    }
                    
                ]
            }";

            var gallery = JsonConvert.DeserializeObject<Gallery>(stringJsonData);

            //1. Вивести на консоль всі картини
            Console.WriteLine("Список картин:");
            foreach(var painting in gallery.Paintings)
            {
                Console.WriteLine($"Code: {painting.Code}, Artist: {painting.Artist}, Title: {painting.Title}, Price: {painting.Price}, Status: {painting.Status}");
            }

            //2.Пошук за кодом
            Console.WriteLine("\nВведіть код картини, для отримання інформації:");
            int inputCode = int.Parse(Console.ReadLine());

            var foundPainting = gallery.Paintings.Find(p => p.Code == inputCode);
            if (foundPainting != null)
            {
                Console.WriteLine($"\nPainting is found! Artist: {foundPainting.Artist}, Title: {foundPainting.Title}, Price: {foundPainting.Price}");
            }
            else
            {
                Console.WriteLine("\nКартина з таким кодом не знайдена.");
            }

            //3. Загальна вартість картин у запаснику

            double totalPricePaintingInStorage = 0;
            foreach(var painting in gallery.Paintings)
            {
                if (painting.Status == 2)
                {
                    totalPricePaintingInStorage += painting.Price;
                }
            }

            Console.WriteLine($"\nСумарна сума картин в запасі: {totalPricePaintingInStorage}");

            //4. Запис обʼєкта до файлу
            var serializedObject = JsonConvert.SerializeObject(gallery);
            Console.WriteLine(serializedObject);

            // зберегти в файл
            // serialize JSON to a string and then write string to a file
            File.WriteAllText(@"/Users/husll/Desktop/IT_at_all/2_курс/Програмування_Антосяк/JsonFile/jsonFile.json", serializedObject);

        }
    }
}