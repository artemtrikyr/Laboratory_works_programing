﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string xmlFile = @"/Users/husll/Desktop/IT_at_all/2_курс/Програмування_Антосяк/XmlFile/xmlFile.xml";

            //Формування XML-файлу 
            using (XmlTextWriter writer = new XmlTextWriter(xmlFile, null))
            {
                writer.WriteStartDocument();
                writer.WriteComment("Created @ " + DateTime.Now.ToString());
                writer.WriteStartElement("gallery");

                // 1 картина
                writer.WriteStartElement("painting");
                writer.WriteAttributeString("code", "001");
                writer.WriteElementString("artist", "Петренко");
                writer.WriteElementString("title", "Сонце");
                writer.WriteElementString("price", "1000");
                writer.WriteElementString("status", "1");
                writer.WriteEndElement();

                // 2 картина
                writer.WriteStartElement("painting");
                writer.WriteAttributeString("code", "002");
                writer.WriteElementString("artist", "Іваненко");
                writer.WriteElementString("title", "Море");
                writer.WriteElementString("price", "2000");
                writer.WriteElementString("status", "2");
                writer.WriteEndElement();

                // 3 картина
                writer.WriteStartElement("painting");
                writer.WriteAttributeString("code", "003");
                writer.WriteElementString("artist", "Сидоренко");
                writer.WriteElementString("title", "Ліс");
                writer.WriteElementString("price", "3000");
                writer.WriteElementString("status", "3");
                writer.WriteEndElement();

                // 4 картина
                writer.WriteStartElement("painting");
                writer.WriteAttributeString("code", "004");
                writer.WriteElementString("artist", "Коваленко");
                writer.WriteElementString("title", "Гори");
                writer.WriteElementString("price", "1500");
                writer.WriteElementString("status", "2");
                writer.WriteEndElement();

                // 5 картина
                writer.WriteStartElement("painting");
                writer.WriteAttributeString("code", "005");
                writer.WriteElementString("artist", "Лисенко");
                writer.WriteElementString("title", "Озеро");
                writer.WriteElementString("price", "4500");
                writer.WriteElementString("status", "2");
                writer.WriteEndElement();

                writer.WriteEndElement(); // </gallery>
                writer.WriteEndDocument();
            }

            Console.WriteLine("Файл створено");

            var paintingList = new List<dynamic>();
            using (XmlTextReader reader = new XmlTextReader(xmlFile))
            {
                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Element && reader.Name == "painting")
                    {
                        var code = reader.GetAttribute("code");
                        reader.ReadStartElement("painting");
                        var artist = reader.ReadElementString("artist");
                        var title = reader.ReadElementString("title");
                        var price = reader.ReadElementString("price");
                        var status = reader.ReadElementString("status");

                        paintingList.Add(new
                        {
                            code,
                            artist,
                            title,
                            price = Convert.ToInt16(price),
                            status = Convert.ToInt32(status)
                        });

                    }
                }
            }

            foreach(var painting in paintingList)
            {
                Console.WriteLine($"Код: {painting.code}, Художник: {painting.artist}, Назва: {painting.title}, Ціна: {painting.price}, Статус: {painting.status}");
            }

            //Картина яку потрібно найти
            string codeToFind = "002";
            var foundPainting = paintingList.FirstOrDefault(p => p.code == codeToFind);

            if (foundPainting != null)
            {
                Console.WriteLine($"\nЗа кодом {codeToFind} знайдено:");
                Console.WriteLine($"Художник: {foundPainting.artist}, Назва: {foundPainting.title}, Ціна: {foundPainting.price} грн");
            }
            else
            {
                Console.WriteLine($"\nКартина з кодом {codeToFind} не знайдена.");

            }

            var totalPriceInStorage = paintingList
                .Where(p => p.status == 2)
                 .Sum(p => p.price);

            Console.WriteLine($"\nСумарна ціна картин у запаснику: {totalPriceInStorage} грн");

            Console.ReadKey();
        }
    }
}